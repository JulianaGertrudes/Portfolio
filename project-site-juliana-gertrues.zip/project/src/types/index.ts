export interface Project {
  id: number;
  title: string;
  description: string;
  category: 'data' | 'automation' | 'ai';
  image: string;
  technologies: string[];
  url?: string;
}

export type ThemeMode = 'light' | 'dark';
export type Language = 'en' | 'pt';