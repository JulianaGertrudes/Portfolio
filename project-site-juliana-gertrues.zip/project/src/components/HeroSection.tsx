import React from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronDown } from 'lucide-react';

const HeroSection: React.FC = () => {
  const { t } = useTranslation();

  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-primary-50 dark:bg-primary-950 pt-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex flex-col items-center text-center animate-fade-in">
          <p className="text-accent-600 font-medium mb-4">{t('hero.greeting')}</p>
          <div className="flex items-center gap-8 mb-6">
            <div className="flex flex-col items-center">
              <h1 className="text-4xl md:text-6xl font-bold text-primary-900 dark:text-white">
                Juliana Gertrudes
              </h1>
            </div>
            <img 
              src="https://images.pexels.com/photos/3796217/pexels-photo-3796217.jpeg?auto=compress&cs=tinysrgb&w=800" 
              alt="Juliana Gertrudes" 
              className="w-32 h-32 rounded-full object-cover border-4 border-accent-600 shadow-lg"
            />
          </div>
          <h2 className="text-2xl md:text-3xl font-medium text-primary-700 dark:text-primary-200 mb-8">
            {t('hero.title')}
          </h2>
          <p className="text-lg text-primary-600 dark:text-primary-300 max-w-2xl mb-10">
            {t('hero.description')}
          </p>
          <a 
            href="#projects" 
            className="bg-accent-600 hover:bg-accent-700 text-white px-8 py-3 rounded-md font-medium transition-colors duration-300"
          >
            {t('hero.cta')}
          </a>
          
          <div className="absolute bottom-10 animate-bounce">
            <a href="#about" aria-label="Scroll down">
              <ChevronDown className="w-10 h-10 text-accent-600" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;