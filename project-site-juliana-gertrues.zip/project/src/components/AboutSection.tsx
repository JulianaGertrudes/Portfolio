import React from 'react';
import { useTranslation } from 'react-i18next';
import { Code, Database, Cpu, LineChart, Settings, Notebook as Robot } from 'lucide-react';

const AboutSection: React.FC = () => {
  const { t } = useTranslation();

  const skills = [
    { name: 'Programming', icon: <Code className="w-6 h-6 text-accent-600" /> },
    { name: 'Data Analysis', icon: <Database className="w-6 h-6 text-accent-600" /> },
    { name: 'Machine Learning', icon: <Cpu className="w-6 h-6 text-accent-600" /> },
    { name: 'Data Visualization', icon: <LineChart className="w-6 h-6 text-accent-600" /> },
    { name: 'Process Automation', icon: <Settings className="w-6 h-6 text-accent-600" /> },
    { name: 'AI Development', icon: <Robot className="w-6 h-6 text-accent-600" /> },
  ];

  return (
    <section id="about" className="py-20 bg-white dark:bg-primary-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16 animate-slide-up">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-900 dark:text-white mb-4">
            {t('about.title')}
          </h2>
          <p className="text-lg text-primary-600 dark:text-primary-300">
            {t('about.description')}
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-primary-900 dark:text-white mb-4">
              {t('about.skills')}
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              {skills.map((skill, index) => (
                <div 
                  key={index} 
                  className="flex items-center p-4 bg-primary-50 dark:bg-primary-800 rounded-lg hover:shadow-md transition-shadow"
                >
                  {skill.icon}
                  <span className="ml-3 text-primary-700 dark:text-primary-200">{skill.name}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-primary-900 dark:text-white mb-4">
                {t('about.experience')}
              </h3>
              <div className="space-y-4">
                <div className="border-l-4 border-accent-600 pl-4 py-2">
                  <h4 className="text-lg font-semibold text-primary-800 dark:text-primary-100">Data Intern</h4>
                  <p className="text-primary-600 dark:text-primary-300">B3, Brasil Bolsa e Balcão • 2024 - Present</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-primary-900 dark:text-white mb-4">
                {t('about.education')}
              </h3>
              <div className="border-l-4 border-accent-600 pl-4 py-2">
                <h4 className="text-lg font-semibold text-primary-800 dark:text-primary-100">Technology Degree in Systems Analysis and Development</h4>
                <p className="text-primary-600 dark:text-primary-300">Universidade São Judas Tadeu • 2024 - 2026</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;