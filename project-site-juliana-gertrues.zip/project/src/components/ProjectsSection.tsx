import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import projects from '../data/projects';
import ProjectCard from './ProjectCard';

type Category = 'all' | 'data' | 'automation' | 'ai';

const ProjectsSection: React.FC = () => {
  const { t } = useTranslation();
  const [activeCategory, setActiveCategory] = useState<Category>('all');

  const filteredProjects = activeCategory === 'all' 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  const categories: { value: Category; label: string }[] = [
    { value: 'all', label: t('projects.categories.all') },
    { value: 'data', label: t('projects.categories.data') },
    { value: 'automation', label: t('projects.categories.automation') },
    { value: 'ai', label: t('projects.categories.ai') },
  ];

  return (
    <section id="projects" className="py-20 bg-primary-50 dark:bg-primary-950">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12 animate-slide-up">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-900 dark:text-white mb-4">
            {t('projects.title')}
          </h2>
          <p className="text-lg text-primary-600 dark:text-primary-300">
            {t('projects.description')}
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.value}
              onClick={() => setActiveCategory(category.value)}
              className={`px-6 py-2 rounded-full transition-colors ${
                activeCategory === category.value
                  ? 'bg-accent-600 text-white'
                  : 'bg-white dark:bg-primary-800 text-primary-700 dark:text-primary-200 hover:bg-primary-100 dark:hover:bg-primary-700'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;