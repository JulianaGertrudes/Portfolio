import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../contexts/ThemeContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Menu, X, Moon, Sun, Globe } from 'lucide-react';

const Header: React.FC = () => {
  const { t } = useTranslation();
  const { theme, toggleTheme } = useTheme();
  const { language, toggleLanguage } = useLanguage();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: t('nav.home'), href: '#home' },
    { name: t('nav.about'), href: '#about' },
    { name: t('nav.projects'), href: '#projects' },
    { name: t('nav.contact'), href: '#contact' },
  ];

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white dark:bg-primary-900 shadow-md' 
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <a href="#home" className="text-2xl font-bold text-primary-900 dark:text-white">
            Portfolio
          </a>

          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                className="text-primary-800 dark:text-primary-100 hover:text-accent-600 dark:hover:text-accent-400 transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Desktop Controls */}
          <div className="hidden md:flex items-center space-x-4">
            <button 
              onClick={toggleLanguage}
              className="p-2 rounded-full text-primary-800 dark:text-primary-100 hover:bg-primary-100 dark:hover:bg-primary-800 transition-colors"
              aria-label={language === 'en' ? t('language.pt') : t('language.en')}
            >
              <Globe className="w-5 h-5 text-accent-600" />
              <span className="sr-only">{language === 'en' ? t('language.pt') : t('language.en')}</span>
            </button>
            
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full text-primary-800 dark:text-primary-100 hover:bg-primary-100 dark:hover:bg-primary-800 transition-colors"
              aria-label={theme === 'dark' ? t('theme.light') : t('theme.dark')}
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-accent-600" />
              ) : (
                <Moon className="w-5 h-5 text-accent-600" />
              )}
              <span className="sr-only">{theme === 'dark' ? t('theme.light') : t('theme.dark')}</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center space-x-4">
            <button 
              onClick={toggleLanguage}
              className="p-2 rounded-full text-primary-800 dark:text-primary-100 hover:bg-primary-100 dark:hover:bg-primary-800 transition-colors"
              aria-label={language === 'en' ? t('language.pt') : t('language.en')}
            >
              <Globe className="w-5 h-5 text-accent-600" />
            </button>
            
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full text-primary-800 dark:text-primary-100 hover:bg-primary-100 dark:hover:bg-primary-800 transition-colors"
              aria-label={theme === 'dark' ? t('theme.light') : t('theme.dark')}
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-accent-600" />
              ) : (
                <Moon className="w-5 h-5 text-accent-600" />
              )}
            </button>
            
            <button
              onClick={toggleMenu}
              className="p-2 rounded-full text-primary-800 dark:text-primary-100 hover:bg-primary-100 dark:hover:bg-primary-800 transition-colors"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <nav className="md:hidden bg-white dark:bg-primary-900 shadow-lg animate-slide-down">
          <div className="container mx-auto px-4 py-4">
            <div className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href}
                  className="text-lg text-primary-800 dark:text-primary-100 hover:text-accent-600 dark:hover:text-accent-400 transition-colors py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
            </div>
          </div>
        </nav>
      )}
    </header>
  );
};

export default Header;