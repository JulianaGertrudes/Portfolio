import React from 'react';
import { useTranslation } from 'react-i18next';
import { Heart, Github, Twitter, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  const { t } = useTranslation();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-10 bg-primary-900 dark:bg-primary-950 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Portfolio</h3>
            <p className="text-primary-300 mb-4">
              Professional portfolio showcasing projects in Data, Automation, and AI.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="text-primary-300 hover:text-accent-400 transition-colors"
                aria-label="Github"
              >
                <Github className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="text-primary-300 hover:text-accent-400 transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="text-primary-300 hover:text-accent-400 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#home" className="text-primary-300 hover:text-accent-400 transition-colors">
                  {t('nav.home')}
                </a>
              </li>
              <li>
                <a href="#about" className="text-primary-300 hover:text-accent-400 transition-colors">
                  {t('nav.about')}
                </a>
              </li>
              <li>
                <a href="#projects" className="text-primary-300 hover:text-accent-400 transition-colors">
                  {t('nav.projects')}
                </a>
              </li>
              <li>
                <a href="#contact" className="text-primary-300 hover:text-accent-400 transition-colors">
                  {t('nav.contact')}
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">{t('contact.title')}</h3>
            <ul className="space-y-2">
              <li className="text-primary-300">
                <strong>{t('contact.email')}:</strong> contact@example.com
              </li>
              <li className="text-primary-300">
                <strong>{t('contact.phone')}:</strong> +1 (123) 456-7890
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-primary-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-primary-300 text-sm">
            &copy; {currentYear} John Doe. {t('footer.rights')}
          </p>
          <p className="text-primary-300 text-sm flex items-center mt-4 md:mt-0">
            {t('footer.madeWith')} <Heart className="w-4 h-4 text-accent-600 mx-1" /> & React
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;