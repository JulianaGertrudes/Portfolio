const pt = {
  nav: {
    home: 'Início',
    about: 'Sobre',
    projects: 'Projetos',
    contact: 'Contato',
  },
  hero: {
    greeting: 'Olá, eu sou',
    title: 'Desenvolvedora & Engenheira de Dados',
    description: 'Focada em criar soluções inovadoras com Dados, Automação e IA',
    cta: 'Ver Meu Trabalho',
  },
  about: {
    title: 'Sobre Mim',
    description: `Sou uma desenvolvedora apaixonada começando minha carreira na indústria de tecnologia. 
    Estou em busca de desenvolver soluções para empresas aproveitarem seus dados e automatizar processos 
    para aumentar a eficiência e obter insights valiosos.`,
    skills: 'Habilidades',
    experience: 'Experiência',
    education: 'Educação',
  },
  projects: {
    title: 'Meus Projetos',
    description: 'Uma demonstração do meu trabalho em diferentes áreas',
    categories: {
      all: 'Todos',
      data: 'Dados',
      automation: 'Automação',
      ai: 'IA',
    },
    viewProject: 'Ver Projeto',
  },
  contact: {
    title: 'Entre em Contato',
    description: 'Tem uma pergunta ou quer trabalhar junto? Sinta-se à vontade para entrar em contato.',
    formName: 'Nome',
    formEmail: 'Email',
    formSubject: 'Assunto',
    formMessage: 'Mensagem',
    formSubmit: 'Enviar Mensagem',
    info: 'Informações de Contato',
    email: 'Email',
    phone: 'Telefone',
    linkedin: 'LinkedIn',
  },
  footer: {
    rights: 'Todos os Direitos Reservados',
    madeWith: 'Feito com',
  },
  theme: {
    light: 'Modo Claro',
    dark: 'Modo Escuro',
  },
  language: {
    en: 'Inglês',
    pt: 'Português',
  },
};

export default pt;