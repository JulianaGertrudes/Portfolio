const en = {
  nav: {
    home: 'Home',
    about: 'About',
    projects: 'Projects',
    contact: 'Contact',
  },
  hero: {
    greeting: 'Hello, I am',
    title: 'Developer & Data Specialist',
    description: 'Focused on creating innovative solutions with Data, Automation and AI',
    cta: 'View My Work',
  },
  about: {
    title: 'About Me',
    description: `I am a passionate developer starting my career in the technology industry. I am looking to develop solutions 
    that help businesses leverage their data and automate processes to increase efficiency and gain valuable insights.`,
    skills: 'Skills',
    experience: 'Experience',
    education: 'Education',
  },
  projects: {
    title: 'My Projects',
    description: 'A showcase of my work across different domains',
    categories: {
      all: 'All',
      data: 'Data',
      automation: 'Automation',
      ai: 'AI',
    },
    viewProject: 'View Project',
  },
  contact: {
    title: 'Contact Me',
    description: 'Have a question or want to work together? Feel free to reach out.',
    formName: 'Name',
    formEmail: 'Email',
    formSubject: 'Subject',
    formMessage: 'Message',
    formSubmit: 'Send Message',
    info: 'Contact Information',
    email: 'Email',
    phone: 'Phone',
    linkedin: 'LinkedIn',
  },
  footer: {
    rights: 'All Rights Reserved',
    madeWith: 'Made with',
  },
  theme: {
    light: 'Light Mode',
    dark: 'Dark Mode',
  },
  language: {
    en: 'English',
    pt: 'Portuguese',
  },
};

export default en;