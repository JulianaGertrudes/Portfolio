import { Project } from '../types';

const projects: Project[] = [
  {
    id: 1,
    title: 'Data Visualization Dashboard',
    description: 'Interactive dashboard for visualizing complex datasets with filtering capabilities.',
    category: 'data',
    image: 'https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    technologies: ['React', 'D3.js', 'Python', 'PostgreSQL'],
    url: '#',
  },
  {
    id: 2,
    title: 'Predictive Analytics Tool',
    description: 'Tool that uses machine learning to predict business trends and outcomes.',
    category: 'data',
    image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    technologies: ['Python', 'TensorFlow', 'Pandas', 'Scikit-learn'],
    url: '#',
  },
  {
    id: 3,
    title: 'Workflow Automation System',
    description: 'System that automates repetitive business processes and workflows.',
    category: 'automation',
    image: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    technologies: ['Node.js', 'Express', 'MongoDB', 'RPA'],
    url: '#',
  },
  {
    id: 4,
    title: 'Document Processing AI',
    description: 'AI-powered solution for automated document processing and data extraction.',
    category: 'ai',
    image: 'https://images.pexels.com/photos/9469313/pexels-photo-9469313.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    technologies: ['Python', 'Computer Vision', 'NLP', 'OCR'],
    url: '#',
  },
  {
    id: 5,
    title: 'Chatbot Platform',
    description: 'Intelligent conversational AI platform for customer service.',
    category: 'ai',
    image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    technologies: ['React', 'Node.js', 'NLP', 'API.AI'],
    url: '#',
  },
  {
    id: 6,
    title: 'Task Automation Tool',
    description: 'Desktop application that automates repetitive tasks with a simple interface.',
    category: 'automation',
    image: 'https://images.pexels.com/photos/7014337/pexels-photo-7014337.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    technologies: ['Electron', 'JavaScript', 'Python', 'Selenium'],
    url: '#',
  },
];

export default projects;